package sendspace;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

import org.xml.sax.SAXException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.codec.digest.DigestUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class SendspaceServlet extends HttpServlet {

	public static final String SENDSPACE_TOKEN = "SENDSPACE_TOKEN";
	
	public String xyz = "folder9";


	// public String list10 = null;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String api_key = request.getParameter("api_key");
		String user_name = request.getParameter("user_name");
		String password = request.getParameter("password");
		String MD5_Password = DigestUtils.md5Hex(password);

		
		URL url = new URL("http://api.sendspace.com/rest/?");
		Map<String, Object> params = new LinkedHashMap<>();
		params.put("method", "auth.createtoken");
		params.put("api_key", api_key);
		params.put("api_version", "1.0");
		
		StringBuilder postData = new StringBuilder();
		for (Map.Entry<String, Object> param : params.entrySet()) {
			if (postData.length() != 0)
				postData.append('&');
			postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
			postData.append('=');
			postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
		}
		byte[] postDataBytes = postData.toString().getBytes("UTF-8");

		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
		conn.setDoOutput(true);
		conn.getOutputStream().write(postDataBytes);
		try {

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();;
			InputSource is = new InputSource(conn.getInputStream());
			Document doc = builder.parse(is);
			NodeList node = doc.getElementsByTagName("token");
//			NodeList login = doc.getElementsByTagName("result");
			String token = node.item(0).getTextContent();	
			String tokmd5pass = token + MD5_Password ;
			String tokened_password = DigestUtils.md5Hex(tokmd5pass);
			
		
			URL url2 = new URL("http://api.sendspace.com/rest/?");
			
			params.put("method", "auth.login");
			params.put("token", token);
			params.put("user_name", user_name);
			params.put("tokened_password", tokened_password);
			params.put("api_version", "1.0");
			
			StringBuilder posttokenData = new StringBuilder();
			for (Map.Entry<String, Object> param : params.entrySet()) {
				if (posttokenData.length() != 0)
					posttokenData.append('&');
				posttokenData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
				posttokenData.append('=');
				posttokenData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
			}
			
			byte[] posttokenDataBytes = posttokenData.toString().getBytes("UTF-8");

			HttpURLConnection conn2 = (HttpURLConnection) url2.openConnection();
			conn2.setRequestMethod("POST");
			conn2.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn2.setRequestProperty("Content-Length", String.valueOf(posttokenDataBytes.length));
			conn2.setDoOutput(true);
			conn2.getOutputStream().write(posttokenDataBytes);
			try {

				DocumentBuilderFactory factory2 = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder2 = factory2.newDocumentBuilder();;
				InputSource is2 = new InputSource(conn2.getInputStream());
				Document doc2 = builder2.parse(is2);
				NodeList node2 = doc2.getElementsByTagName("session_key");
				String session = node2.item(0).getTextContent();	
				request.getSession().setAttribute(SENDSPACE_TOKEN, node2.item(0).getTextContent());
				String token2 = (String)request.getSession().getAttribute(SENDSPACE_TOKEN);
				System.out.println(session);
				
		/*	
				
				URL url5 = new URL("http://api.sendspace.com/rest/?");
			
				params.put("method", "folders.create");
				params.put("session_key", session);
				params.put("api_version", "1.0");   
				params.put("name", xyz);
				params.put("shared", "0");
				params.put("parent_folder_id", "0");
				
				
				StringBuilder postfolder = new StringBuilder();
				for (Map.Entry<String, Object> param : params.entrySet()) {
					if (postfolder.length() != 0)
						postfolder.append('&');
					postfolder.append(URLEncoder.encode(param.getKey(), "UTF-8"));
					postfolder.append('=');
					postfolder.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
				}
				
				byte[] postfolderBytes = postfolder.toString().getBytes("UTF-8");

				HttpURLConnection conn5 = (HttpURLConnection) url5.openConnection();
				conn5.setRequestMethod("POST");
				conn5.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				conn5.setRequestProperty("Content-Length", String.valueOf(postfolderBytes.length));
				conn5.setDoOutput(true);
				conn5.getOutputStream().write(postfolderBytes);
				
				try {

					DocumentBuilderFactory factory5 = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder5 = factory5.newDocumentBuilder();;
					InputSource is5 = new InputSource(conn5.getInputStream());
					Document doc5 = builder5.parse(is5);
					NodeList sfoldername = doc5.getElementsByTagName("folder");
					 int l = sfoldername.getLength();
						for (l=0;l<sfoldername.getLength();l++)
						{
					String c = sfoldername.item(l).getAttributes().getNamedItem("name").getNodeValue();
					System.out.println(c);
						}
						
				} catch (ParserConfigurationException e) {

				} catch (SAXException e) {

				} catch (IOException e) {

				}
						
/*				
				//////////
				
				URL url3 = new URL("http://api.sendspace.com/rest/?");
				params.put("method", "folders.getall");
				params.put("session_key", session);
				params.put("api_version", "1.0");
				
				StringBuilder postData3 = new StringBuilder();
				for (Map.Entry<String, Object> param : params.entrySet()) {
					if (postData3.length() != 0)
						postData3.append('&');
					postData3.append(URLEncoder.encode(param.getKey(), "UTF-8"));
					postData3.append('=');
					postData3.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
				}
				byte[] postDataBytes3 = postData3.toString().getBytes("UTF-8");

				HttpURLConnection conn3 = (HttpURLConnection) url3.openConnection();
				conn3.setRequestMethod("POST");
				conn3.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				conn3.setRequestProperty("Content-Length", String.valueOf(postDataBytes3.length));
				conn3.setDoOutput(true);
				conn3.getOutputStream().write(postDataBytes3);		
				 try {
			        	DocumentBuilderFactory factory3 = DocumentBuilderFactory.newInstance();
			            DocumentBuilder builder3 = factory3.newDocumentBuilder();;
			            InputSource is3 = new InputSource(conn3.getInputStream());
			                Document doc3 = builder3.parse(is3);
			                NodeList sfoldername = doc3.getElementsByTagName("folder");
			                //NodeList sfolderid = doc3.getElementsByTagName("folderkey");
			                int k = sfoldername.getLength();
							
							for (k=0;k<sfoldername.getLength();k++)
							{
			
								String c = sfoldername.item(k).getAttributes().getNamedItem("name").getNodeValue();
								
								System.out.println(c);
								
								// System.out.println(sfoldername.item(k).getAttributes().getNamedItem("name").getNodeValue());
							
				
							}
			
				
				
				
				
							} catch (ParserConfigurationException e) {

							} catch (SAXException e) {

							} catch (IOException e) {

							}
				
				
				
				
				///////////////////////
				
	*/	
		
			
			} catch (ParserConfigurationException e) {

			} catch (SAXException e) {

			} catch (IOException e) {

			}
			
			
	
			
			
		} catch (ParserConfigurationException e) {

		} catch (SAXException e) {

		} catch (IOException e) {

		}


	}
}

	
