package sendspace;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class SendSpaceFolderList {
	
	public String [] SFolderName = {};
	public String [] SFolderID = {};
	
	public  Object key(String s) throws IOException {
	
	 URL url3 = new URL("http://api.sendspace.com/rest/?");
     Map<String, Object> params2 = new LinkedHashMap<>();
     params2.put("method", "folders.getContents");
     params2.put("session_key", s);
     params2.put("api_version", "1.0");
     params2.put("folder_id", "0");

     StringBuilder postData3 = new StringBuilder();
     for (Map.Entry<String, Object> param : params2.entrySet()) {
         if (postData3.length() != 0)
             postData3.append('&');
         postData3.append(URLEncoder.encode(param.getKey(), "UTF-8"));
         postData3.append('=');
         postData3.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
     }
     byte[] postDataBytes3 = postData3.toString().getBytes("UTF-8");

     HttpURLConnection conn3 = (HttpURLConnection) url3.openConnection();
     conn3.setRequestMethod("POST");
     conn3.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
     conn3.setRequestProperty("Content-Length", String.valueOf(postDataBytes3.length));
     conn3.setDoOutput(true);
     conn3.getOutputStream().write(postDataBytes3);
     try {
         DocumentBuilderFactory factory3 = DocumentBuilderFactory.newInstance();
         DocumentBuilder builder3 = factory3.newDocumentBuilder();
         InputSource is3 = new InputSource(conn3.getInputStream());
         Document doc3 = builder3.parse(is3);
         NodeList sfoldername = doc3.getElementsByTagName("folder"); 
         ArrayList<String> SendSpaceFolders = new ArrayList<>();
         ArrayList<String> SendSpaceFoldersID = new ArrayList<>();
         int p = sfoldername.getLength();
         for (p = 0; p < sfoldername.getLength(); p++) {
         String y = sfoldername.item(p).getAttributes().getNamedItem("name").getNodeValue();
         SendSpaceFolders.add(y);
         SFolderName = SendSpaceFolders.toArray(SFolderName);
         
         
         String z = sfoldername.item(p).getAttributes().getNamedItem("id").getNodeValue(); 
         SendSpaceFoldersID.add(z);
         SFolderID = SendSpaceFoldersID.toArray(SFolderID);
         
         }       
             

     } catch (ParserConfigurationException e) {

     } catch (SAXException e) {

     } catch (IOException e) {

     }
     
	return null;

     
 	
}
	

	
}
