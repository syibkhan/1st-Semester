package mediafire;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

import org.xml.sax.SAXException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.codec.digest.DigestUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class MediafireServlet extends HttpServlet {

	public static final String MEDIAFIRE_TOKEN = "MEDIAFIRE_TOKEN";
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String app_id = request.getParameter("app_id");
		String api_key = request.getParameter("api_key");
		String string1 = email + password + app_id + api_key;
		//System.out.println(string1);
		String signature = DigestUtils.shaHex(string1);
		
		
		URL url = new URL("https://www.mediafire.com/api/1.1/user/get_session_token.php?");
		Map<String, Object> params = new LinkedHashMap<>();
		params.put("email", email);
		params.put("password", password);
		params.put("application_id", app_id);
		params.put("signature", signature);

		StringBuilder postData = new StringBuilder();
		for (Map.Entry<String, Object> param : params.entrySet()) {
			if (postData.length() != 0)
				postData.append('&');
			postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
			postData.append('=');
			postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
		}
		byte[] postDataBytes = postData.toString().getBytes("UTF-8");

		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
		conn.setDoOutput(true);
		conn.getOutputStream().write(postDataBytes);
		try {

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();;
			InputSource is = new InputSource(conn.getInputStream());
			Document doc = builder.parse(is);
			NodeList session_token = doc.getElementsByTagName("session_token");
			NodeList login = doc.getElementsByTagName("result");
			String login_status = login.item(0).getTextContent();
			// System.out.println( "session token is" +
			// list.item(0).getTextContent());
			// System.out.println( "Login status    " +
			// list1.item(0).getTextContent());
			response.getWriter().print(" Mediafire Login Status" + " " + login_status + " " + "Please log in your Sendspace Account");
			request.getSession().setAttribute(MEDIAFIRE_TOKEN, session_token.item(0).getTextContent());
			String token = (String)request.getSession().getAttribute(MEDIAFIRE_TOKEN); 
		} catch (ParserConfigurationException e) {

		} catch (SAXException e) {

		} catch (IOException e) {

		}


	}
}

	
