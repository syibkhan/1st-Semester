package mediafire;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class MediaFireFolderList {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		String m = (String) session.getAttribute("MEDIAFIRE_TOKEN");	
		URL url = new URL("http://www.mediafire.com/api/1.1/folder/get_content.php?");
		Map<String, Object> params = new LinkedHashMap<>();
		params.put("folder_key", "myfiles");
		params.put("session_token", m);
		params.put("content_type", "folders");

		StringBuilder postData = new StringBuilder();
		for (Map.Entry<String, Object> param : params.entrySet()) {
			if (postData.length() != 0)
				postData.append('&');
			postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
			postData.append('=');
			postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
		}
		byte[] postDataBytes = postData.toString().getBytes("UTF-8");

		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
		conn.setDoOutput(true);
		conn.getOutputStream().write(postDataBytes);

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			InputSource is = new InputSource(conn.getInputStream());
			Document doc = builder.parse(is);
			NodeList foldername = doc.getElementsByTagName("name");
			ArrayList<String> mediaFireFolders = new ArrayList<String>();
			int i = foldername.getLength();
			for (i = 0; i < foldername.getLength(); i++) {

				String z = foldername.item(i).getTextContent();			
				mediaFireFolders.add (z);
				String [] arrayB = {};
				arrayB = mediaFireFolders.toArray(arrayB);
				System.out.println("Media fire folders  " + arrayB  + "END");
			}
	

		} catch (ParserConfigurationException e) {

		} catch (SAXException e) {

		} catch (IOException e) {

		}
   	}
	
}
