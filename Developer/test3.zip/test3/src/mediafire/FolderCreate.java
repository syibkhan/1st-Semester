package mediafire;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class FolderCreate {

	public static void main(String[] args) {

		  URL url5 = new URL("http://api.sendspace.com/rest/?");
		  Map<String, Object> params2 = new LinkedHashMap<>();
		  params2.put("method", "folders.create");
		  params2.put("session_key", s); params2.put("name", z);
		  params2.put("shared", "0"); params2.put("parent_folder_id","0");
		  
		  //System.out.println(s +" and  "+ z);
		  
		  StringBuilder postfolder = new StringBuilder(); for
		  (Map.Entry<String, Object> param : params2.entrySet()) { if
		  (postfolder.length() != 0) postfolder.append('&');
		  postfolder.append(URLEncoder.encode(param.getKey(),
		  "UTF-8")); postfolder.append('=');
		  postfolder.append(URLEncoder
		  .encode(String.valueOf(param.getValue()), "UTF-8")); }
		  
		  byte[] postfolderBytes =
		  postfolder.toString().getBytes("UTF-8");
		  
		  HttpURLConnection conn5 = (HttpURLConnection)
		  url5.openConnection(); conn5.setRequestMethod("POST");
		  conn5.setRequestProperty("Content-Type",
		  "application/x-www-form-urlencoded");
		  conn5.setRequestProperty("Content-Length",
		  String.valueOf(postfolderBytes.length));
		  conn5.setDoOutput(true);
		  conn5.getOutputStream().write(postfolderBytes);
		  
		  try {
		  
		  DocumentBuilderFactory factory5 =
		  DocumentBuilderFactory.newInstance(); 
		  DocumentBuilder builder5 = factory5.newDocumentBuilder();
		  InputSource is5 = new InputSource(conn5.getInputStream());
		  Document doc5 = builder5.parse(is5);
		  NodeList sfoldername = doc5.getElementsByTagName("folder"); 
		  int l = sfoldername.getLength(); 
		  for
		  (l=0;l<sfoldername.getLength();l++) 
		  { String c = sfoldername.item(l).getAttributes().getNamedItem("name").getNodeValue();
		  System.out.println(c); }
		  
		  } catch (ParserConfigurationException e) {
		  
		  } catch (SAXException e) {
		  
		  } catch (IOException e) {
		  
		  } 
		

	}

}
