package mediafire;

public class twoArrays
{
public static void main(String[] args)
{
//populate the arrays
String [] arrayA ={"dog", "cat" , "chicken"};
String [] arrayB = {"dog", "cat"};


//loop through the contents of arrayA
//and comparing each element to each element in arrayB
//switch variable used to indicate whether a match was found
boolean foundSwitch = false;

//outer loop for all the elements in arrayA[i]
for(int i = 0; i < arrayA.length; i++)
{
//inner loop for all the elements in arrayB[j]
for (int j = 0; j < arrayB.length;j++)
{
//compare arrayA to arrayB and output results
if( arrayA[i].equals(arrayB[j]))
{
foundSwitch = true;
System.out.println( "arrayA element"+ arrayA[i] + " was found in arrayB" );
}
}
if (foundSwitch == false)
{
System.out.println( "arrayA element"+ arrayA[i] + " was not found in arrayB" );
}
//set foundSwitch bool back to false
foundSwitch = false;
}
}
}