package com.charles.okojie;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;



public class MediaFile {
	
HttpClient httpclient = null;
HttpGet httpGet = null;
HttpResponse responsevalue = null;
private String application_id = "";
private String API_id = "";
String xml = null;
static String token = "";

public MediaFile(String application_id, String ApI_id) {
this.application_id = application_id;
this.API_id = ApI_id;
}

public void connect(String email, String password) {
//String token = "";
//not to be used the string...
HttpClient httpclient = null;
HttpGet httpGet = null;
HttpResponse responsevalue = null;
String signature = email + password + application_id + API_id;
String digest = DigestUtils.shaHex(signature);
String httpRequest = "https://www.mediafire.com/api/user/get_session_token.php?";
httpRequest += "email=" + email + "&" + "password=" + password + "&";
httpRequest += "application_id=" + application_id + "&" + "signature=";
httpRequest += digest + "&version=1";
httpclient = HttpClientBuilder.create().build();
httpGet = new HttpGet(httpRequest);

try {
responsevalue = httpclient.execute(httpGet);
System.out.println(responsevalue.getStatusLine());
HttpEntity entityvalue = responsevalue.getEntity();
//InputStream stream = null;
try {
//stream = entityvalue.getContent();
xml = EntityUtils.toString(entityvalue);
System.out.println(xml);
DocumentBuilderFactory builderFactory = DocumentBuilderFactory
.newInstance();
DocumentBuilder builder = null;
builder = builderFactory.newDocumentBuilder();
Document xmlDocument = builder.parse(new ByteArrayInputStream(
xml.getBytes()));
XPathFactory factory = XPathFactory.newInstance();
XPath path = factory.newXPath();
token = path.compile("response/session_token").evaluate(
xmlDocument);
} catch (ParseException e) {
} catch (IllegalStateException e) {
} catch (XPathExpressionException e) {
} catch (ParserConfigurationException e) {
} catch (SAXException e) {
}
} catch (ClientProtocolException e) {
e.printStackTrace();
} catch (IOException e) {
e.printStackTrace();
} finally {
httpGet.releaseConnection();
}

}

public UserInfo getInfo() {
String httpRequest = "http://www.mediafire.com/api/user/get_info.php?";
httpRequest += "session_token=" + token + "&version=1";
System.out.println(httpRequest);
httpclient = HttpClientBuilder.create().build();
httpGet = new HttpGet(httpRequest);
try {
responsevalue = httpclient.execute(httpGet);
System.out.println(responsevalue.getStatusLine());
HttpEntity entityvalue = responsevalue.getEntity();
//InputStream stream = null;
try {
//stream = entityvalue.getContent();
xml = EntityUtils.toString(entityvalue);
System.out.println(xml);
} catch (ParseException e) {
} catch (IllegalStateException e) {
}
} catch (ClientProtocolException e) {
} catch (IOException e) {
}
UserInfo obj = new UserInfo();
obj.setEmail(parse_Element(xml, "email"));
obj.setFirst_name(parse_Element(xml,"first_name"));
obj.setLast_name(parse_Element(xml,"last_name"));
obj.setDisplay_name(parse_Element(xml,"display_name"));
obj.setGender(parse_Element(xml,"gender"));
obj.setBirth_date(parse_Element(xml,"birth_day"));
obj.setLocation(parse_Element(xml,"location"));
obj.setWebsite(parse_Element(xml,"website"));
obj.setPremium(parse_Element(xml,"premium"));
obj.setBandwidth(parse_Element(xml,"bandwidth"));
obj.setCreated(parse_Element(xml,"created"));
obj.setValidated(Boolean.valueOf(parse_Element(xml,"validated")));
return obj;
}
private String parse_Element(String xml, String variable) {
DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
DocumentBuilder builder = null;
String result = "";
try {
builder = builderFactory.newDocumentBuilder();
Document xmlDocument= builder.parse(new ByteArrayInputStream(xml.getBytes()));
XPathFactory factory = XPathFactory.newInstance();
XPath path = factory.newXPath();
result = path.compile("/response/user_info/"+variable).evaluate(xmlDocument);
} catch (SAXException e) {
} catch (IOException e) {
}catch (XPathExpressionException e) {
}catch (ParserConfigurationException e){
}
return result;
}
}