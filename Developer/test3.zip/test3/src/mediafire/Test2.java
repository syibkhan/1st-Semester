package mediafire;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
		MediafireServlet abc = new MediafireServlet();
		
		String token = (String)request.getSession().getAttribute(MEDIAFIRE_TOKEN);
		
		String z = null;
		MediafireServlet.MEDIAFIRE_TOKEN = z;
		 System.out.println(z);

	}

}
