package mediafire;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MediafireFileList {

	public String session_token = null;

	public static int main(String[] args) {
		return 0;
		
//		object = new MediafireServlet();
//		
//		String session_token = null;
//		object.list10 = session_token;
//		System.out.println(session_token);
//		
		
		
//		MediafireServlet o = new MediafireServlet();
//		
//		System.out.println("code returning " + o.list11);
		

	}
	
	
	public String returnVar(String list10) {
		
	list10;
		
		public  void doPost1 (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 
		
	return list10;
	}

}
