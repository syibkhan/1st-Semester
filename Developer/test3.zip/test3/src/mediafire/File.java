package mediafire;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class File {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
	//	MediafireServlet abc = new MediafireServlet();
		public void doPost(HttpServletRequest request, HttpServletResponse response) throws  IOException {	
		
		URL url = new URL("http://www.mediafire.com/api/1.1/folder/get_content.php?");
		Map<String, Object> params = new LinkedHashMap<>();
		params.put("folder_key", "myfiles");
		params.put("session_token", "0c25932852986c8ae3527563f71f574f195b80961616239066bf80b782fc255cd1145d23c0a65958e61598e16f1c576c37e592c49a2d46ad6a31b565ff57d8befd645ce39e663a1c");
		params.put("content_type", "folders");
	

		StringBuilder postData = new StringBuilder();
		for (Map.Entry<String, Object> param : params.entrySet()) {
			if (postData.length() != 0)
				postData.append('&');
			postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
			postData.append('=');
			postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
		}
		byte[] postDataBytes = postData.toString().getBytes("UTF-8");

		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
		conn.setDoOutput(true);
		conn.getOutputStream().write(postDataBytes);
		try {

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();;
			InputSource is = new InputSource(conn.getInputStream());
			Document doc = builder.parse(is);
			NodeList folderkey = doc.getElementsByTagName("folderkey");
			String x = folderkey.item(0).getTextContent();
			
			String[] y = new String[x.length()];
			int i = 0 ;
			y [i] = x;
			
			System.out.println(x);
			
			
			// System.out.println( "session token is" +
			// list.item(0).getTextContent());
			// System.out.println( "Login status    " +
			// list1.item(0).getTextContent());
			//response.getWriter().print(" Mediafire Login Status" + " " + login_status + " " + "Please log in your Sendspace Account");
			
			//request.getSession().setAttribute(MEDIAFIRE_TOKEN, session_token.item(0).getTextContent());
			
		
			//String token = (String)request.getSession().getAttribute(MEDIAFIRE_TOKEN);
			
			//System.out.println(token);
			
			
		} catch (ParserConfigurationException e) {

		} catch (SAXException e) {

		} catch (IOException e) {

		}

	}
}
}
