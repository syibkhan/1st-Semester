package mediafire;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class DownloadLink {
	
	
	public void download (String m, String quick ) throws IOException{
		
		

		URL url = new URL("http://www.mediafire.com/api/1.2/file/get_links.php?");
		Map<String, Object> params = new LinkedHashMap<>();
		params.put("link_type", "direct_download" );
		params.put("session_token", m);
		params.put("quick_key", quick );
		params.put("content_type", "files");
		params.put("response_format", "xml");
		
		StringBuilder postData = new StringBuilder();
		for (Map.Entry<String, Object> param : params.entrySet()) {
			if (postData.length() != 0)
				postData.append('&');
			postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
			postData.append('=');
			postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
		}
		byte[] postDataBytes = postData.toString().getBytes("UTF-8");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
		conn.setDoOutput(true);
		conn.getOutputStream().write(postDataBytes);
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();;
			InputSource is = new InputSource(conn.getInputStream());
			Document doc = builder.parse(is);
			NodeList download = doc.getElementsByTagName("direct_download");
			ArrayList<String> linklist = new ArrayList<String>();
			int i = download.getLength();
			for (i = 0; i < download.getLength(); i++) {
				String w = download.item(i).getTextContent();
				linklist.add (w);
				String [] downloadlinkList = {};
				downloadlinkList = linklist.toArray(downloadlinkList);
				System.out.println( "downloadlink are "+ Arrays.toString(downloadlinkList) );	
			}
			
			
		} catch (ParserConfigurationException e) {

		} catch (SAXException e) {

		} catch (IOException e) {

		}
		
		
		
		
	}

}
