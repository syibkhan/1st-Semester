package com;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;





public class UploadProductDetails {

	


    public void uploadProductDetails(String filePath, String fileName)
    {

        InputStream inputStream;
        try
        {
            inputStream = new FileInputStream(new File(filePath));
            byte[] data;
            try
            {
                data = IOUtils.toByteArray(inputStream);

                HttpClient httpClient = new HttpClient();

                httpClient.getParams().setParameter(CoreProtocolPNames.USER_AGENT,
                        System.getProperty("http.agent"));



                HttpPost httpPost = new HttpPost("http://ipaddress");


                InputStreamBody inputStreamBody = new InputStreamBody(new ByteArrayInputStream(data), "abc.png");
                MultipartEntity multipartEntity = new MultipartEntity();
                multipartEntity.addPart("file", inputStreamBody);


                httpPost.setEntity(multipartEntity);
                HttpResponse httpResponse = httpClient.execute(httpPost);

                // Handle response back from script.
                if(httpResponse != null) {
                    //Toast.makeText(getBaseContext(),  "Upload Completed. ", 2000).show();

                } else { // Error, no response.
                    //Toast.makeText(getBaseContext(),  "Server Error. ", 2000).show();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        }
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
