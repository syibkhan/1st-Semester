package com;

import java.io.File;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
  
public class DemoFileUploader {

public static void main(String[] args) throws Exception {
    HttpClient httpclient = new DefaultHttpClient();
    HttpPost httppost = new HttpPost("http://fs07u.sendspace.com/apiupload?DESTINATION_DIR=5&UPLOAD_IDENTIFIER=1945318431.1414874617.82EAB438.21.0&MAX_FILE_SIZE=314572800");

    MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);

    reqEntity.addPart("MAX_FILE_SIZE", new StringBody("314572800"));
    reqEntity.addPart("UPLOAD_IDENTIFIERE", new StringBody("1945318431.1414874617.82EAB438.21.0"));
    reqEntity.addPart("extra_info", new StringBody("mAngWPK%2FMH%2Bzykm7wGuOhJaT8E62%3BPdK%2FVamEDgQckXrkAsPlUzbGLFsRu8qwG74pCFEpw0ubSmPA8esBG8Pmr8kQJBvXaLmBk1xmPiyXeQ%3D%3D"));

    FileBody bin = new FileBody(
        new File("D:/Download/87.jpg"));
    reqEntity.addPart("userfile", bin );

    httppost.setEntity(reqEntity);

    System.out.println("executing request " + httppost.getRequestLine());
    HttpResponse response = httpclient.execute(httppost);
    HttpEntity resEntity = response.getEntity();

    if (resEntity != null) {
        String page = EntityUtils.toString(resEntity);
        System.out.println("PAGE :" + page);
    }
    }
}
