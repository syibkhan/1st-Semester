package com;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.BufferedWriter;
import java.net.URL;





public class Media {
	

	public static void main (String[] args) throws IOException
	{

		
		URL url = new URL ("http://upload.wikimedia.org/wikipedia/commons/6/6f/Earth_Eastern_Hemisphere.jpg");
		InputStream stream = url.openStream();
		BufferedReader reader =  new BufferedReader(new InputStreamReader (stream));
		String line = reader.readLine();
		while (line != null)
		{
			//System.out.println(line);
			line = reader.readLine();
		}
		
		BufferedWriter os = new BufferedWriter(new FileWriter("D:/Download/369999.jpg"));
		 
		
		
		System.out.println("Done");
		
		
	}
	
	}

