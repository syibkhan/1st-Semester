package com;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SaveImageFromUrl {

	public static void main(String[] args) throws Exception {
		String imageUrl = "http://upload.wikimedia.org/wikipedia/commons/6/6f/Earth_Eastern_Hemisphere.jpg";
		String destinationFile = "D:/Download/sadi.jpg";

		saveImage(imageUrl, destinationFile);
	}

	public static void saveImage(String imageUrl, String destinationFile) throws IOException {
		
		int size;
		
		URL url = new URL(imageUrl);
	     URLConnection conn = url.openConnection();
	     size = conn.getContentLength();
	     if (size < 0)
	         System.out.println("Could not determine file size.");
	         else
	         System.out.println("The size of file is = "
	         +size + "bytes");
	         conn.getInputStream().close();
		InputStream is = url.openStream();
		OutputStream os = new FileOutputStream(destinationFile);

		byte[] b = new byte[2048];
		int length;

		while ((length = is.read(b)) != -1) {
			os.write(b, 0, length);
		}

		is.close();
		os.close();
	}


	
	
}