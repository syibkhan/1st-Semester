package com;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpPostForm {

	public static void main(String[] args)
	  {
	    try
	    {
	      URL url = new URL( "http://fs01u.sendspace.com/apiupload?DESTINATION_DIR=4&UPLOAD_IDENTIFIER=619395354.1414884456.82EAB438.20.0&MAX_FILE_SIZE=314572800" );
	 
	      HttpURLConnection hConnection = (HttpURLConnection)
	                             url.openConnection();
	      HttpURLConnection.setFollowRedirects( true );
	 
	      hConnection.setDoOutput( true );
	      hConnection.setRequestMethod("POST");	
	 
	      PrintStream ps = new PrintStream( hConnection.getOutputStream() );
	      ps.print("MAX_FILE_SIZE=314572800&amp;param2=10341");
	      ps.close();
	 
	      hConnection.connect();
	 
	      if( HttpURLConnection.HTTP_OK == hConnection.getResponseCode() )
	      {
	        InputStream is = hConnection.getInputStream();
	        OutputStream os = new FileOutputStream("D:/Download/87.jpg");
	        int data;
	        while((data=is.read()) != -1)
	        {
	          os.write(data);
	        }
	        is.close();
	        os.close();
	        hConnection.disconnect();
	      }
	    }
	    catch(Exception ex)
	    {
	      ex.printStackTrace();
	    }
	  }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
